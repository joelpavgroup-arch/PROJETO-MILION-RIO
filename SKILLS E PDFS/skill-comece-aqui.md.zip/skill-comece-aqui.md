---
name: comece-aqui
description: Cria o texto "Comece Aqui" — apresentação de perfil que atrai clientes qualificados e repele curiosos. Texto que vende antes de qualquer post. Use quando o usuário pedir "comece aqui", "texto de apresentação", "descrição de perfil", "sobre mim" ou quiser reescrever como se posiciona.
---

# Comece Aqui

"Comece Aqui" é o texto de apresentação que funciona como filtro de entrada. Não descreve. Posiciona.

## Princípios Fundamentais

### O que diferencia Comece Aqui:

1. **Valida antes de vender** — Reconhece competência do leitor antes de apresentar solução
2. **Nomeia dores invisíveis** — Descreve o que o leitor sente mas não consegue articular
3. **Cria contraste injusto** — Mostra que outros menos competentes ganham mais
4. **Usa metáforas visuais** — Transforma conceitos abstratos em imagens concretas
5. **Assume risco no CTA** — Garantia pública que demonstra confiança absoluta
6. **Flui como conversa** — Lê como se alguém estivesse falando com você

### O que Comece Aqui NÃO é:

- Não é lista de credenciais
- Não é currículo resumido
- Não é promessa vaga de transformação
- Não é sequência de emojis com bullet points
- Não é copy genérica de coach

---

## Coleta Consultiva

Antes de escrever, extraia informações em conversa progressiva:

### Bloco 1: Identidade do Cliente
- Quais profissões/perfis você atende?
- O que eles têm em comum?
- Como eles se descrevem?

### Bloco 2: Competência vs. Percepção
- Por que seu cliente é bom no que faz?
- Por que os outros não enxergam isso?
- Qual a consequência de não ser visto?

### Bloco 3: Frustrações Específicas
- Quais tarefas do dia a dia frustram seu cliente?
- O que ele tenta fazer e sai "uma porcaria"?
- O que os outros fazem igual e parece melhor?

### Bloco 4: Sentimento Resultante
- Como seu cliente se sente quando falha nisso?
- Qual palavra descreve esse sentimento? (fraude, incapaz, invisível)

### Bloco 5: Transformação
- O que muda quando seu cliente resolve isso?
- Qual o resultado tangível?
- Qual o resultado emocional?

### Bloco 6: Prova e Garantia
- O que você faz que prova que funciona?
- Qual garantia você pode dar?
- Em quanto tempo o resultado aparece?

---

## Arquitetura da Comece Aqui

### Bloco 1: Conexão por Identidade
**Função:** Fazer o leitor pensar "isso sou eu".

Estrutura:
```
Provavelmente, você é um [categoria profissional] incrível.
Um [profissão 1], [profissão 2], [profissão 3]…
talvez seja um [profissão 4], [profissão 5], [profissão 6]…
```

Regras:
- Mínimo 4 profissões listadas
- Intercalar profissões de áreas diferentes
- Usar "provavelmente" para suavizar (não soa arrogante)
- Validar competência antes de apontar problema

---

### Bloco 2: Contraste Doloroso
**Função:** Criar gap entre competência real e percepção externa.

Estrutura:
```
…que poderia estar entre os melhores na sua especialidade.
Mas [contexto onde atua], não consegue [ação desejada] nem [resultado esperado].
```

Técnica: Use "poderia" para amplificar a frustração. O potencial não realizado dói mais que a incompetência.

---

### Bloco 3: Consequência Tangível
**Função:** Mostrar o custo real de não resolver.

Estrutura:
```
E então!?
[Consequência 1 — poucos reconhecem].
E então!?
[Consequência 2 — recebe menos que os outros].
```

Regras:
- "E então!?" como pontuação emocional (cria ritmo)
- Consequência deve ser comparativa (você vs. outros)
- Mencionar que outros menos competentes ganham mais

---

### Bloco 4: Validação da Dor
**Função:** Criar cumplicidade. Mostrar que entende.

Estrutura:
```
Com certeza, você já passou por isso.
```

Técnica: Uma frase basta. Afirmativa, não interrogativa. Você sabe que ele passou.

---

### Bloco 5: Situação Específica
**Função:** Provar que você conhece o dia a dia dele.

Estrutura:
```
Tem [oferta valiosa] e precisa:
• [Tarefa específica 1];
• [Tarefa específica 2];
• [Tarefa específica 3].
```

Regras:
- Máximo 3 tarefas
- Tarefas que envolvem comunicação/expressão funcionam melhor
- Usar verbos no infinitivo

---

### Bloco 6: Descrição Vívida da Frustração
**Função:** Descrever a dor melhor do que o leitor conseguiria.

Estrutura:
```
Mas, ao [tentar executar]…
Parece uma porcaria!
```

Regras:
- Linguagem crua, sem filtro
- "Porcaria", "horrível", "ridículo" — palavras que ele pensa mas não fala
- Reticências antes para criar tensão

---

### Bloco 7: Comparação Injusta
**Função:** Amplificar a dor pela comparação.

Estrutura:
```
Outro profissional [faz a mesma coisa]…
E soa brilhante.
```

Técnica: Não precisa explicar por quê. A comparação crua é mais poderosa.

---

### Bloco 8: Sentimento Resultante
**Função:** Nomear o que o leitor sente.

Estrutura:
```
Então…
Você se sente [sentimento profundo].
```

Palavras que funcionam:
- "uma fraude"
- "invisível"
- "incapaz"
- "um amador"

Técnica: Nomear o sentimento cria alívio. "Alguém finalmente entende."

---

### Bloco 9: Metáfora da Solução
**Função:** Transformar a promessa em imagem visual.

Estrutura:
```
O [conteúdo/método] nesse [local] será como [metáfora]:
vai [ação restritiva positiva].
```

Exemplo:
- "camisa de força: vai aprisionar seus piores instintos"
- "bisturi: vai cortar o que não funciona"
- "filtro: vai separar o que importa do ruído"

Regras:
- Metáfora deve ser visual e concreta
- A restrição é apresentada como benefício
- Conectar com a dor apresentada antes

---

### Bloco 10: Promessa Clara
**Função:** Descrever a transformação em verbos de ação.

Estrutura:
```
Você saberá como [ação 1], [ação 2] e [ação 3].
```

Regras:
- Exatamente 3 ações
- Verbos no infinitivo
- Progressão lógica (limpar → organizar → expressar)

---

### Bloco 11: Resultado Desejado
**Função:** Pintar o depois.

Estrutura:
```
Seu [contexto] não será mais [estado negativo].
Será [estado positivo 1] e [estado positivo 2].
```

Técnica: Contraste direto. Antes vs. depois na mesma frase.

---

### Bloco 12: Posicionamento Elevado
**Função:** Definir o novo status.

Estrutura:
```
Você vai se posicionar como [identidade elevada] — [superlativo no mercado].
```

Regras:
- Usar "se posicionar como" (não "ser")
- Superlativo deve ser crível ("a melhor opção", não "o maior do mundo")

---

### Bloco 13: Prova de Ação
**Função:** Mostrar que você pratica o que prega.

Estrutura:
```
Eu acabei de [ação concreta], pra te mostrar [objetivo].
```

Exemplos:
- "construir um novo Instagram do zero"
- "criar uma estrutura completa em 48h"
- "testar esse método com 10 clientes"

Regras:
- Ação deve ser recente ("acabei de")
- Demonstra que você vive o método

---

### Bloco 14: CTA Simples
**Função:** Converter sem fricção.

Estrutura:
```
Se você está lendo isso… [ação].
```

Ações que funcionam:
- "segue"
- "salva"
- "manda DM"

Regra: Uma única ação. Sem opções.

---

### Bloco 15: Garantia Ousada
**Função:** Eliminar risco e demonstrar confiança.

Estrutura:
```
Se, no máximo em [prazo],
eu não [promessa específica]…
[Consequência que você assume]. Eu terei falhado.
```

Exemplo:
- "7 dias / mudar sua forma de vender / dê unfollow"
- "14 dias / gerar seu primeiro cliente / devolvemos o investimento"

Regras:
- Prazo curto (7-30 dias)
- Você assume a culpa ("eu terei falhado")
- Consequência é real e verificável

---

## Padrões de Escrita

### Ritmo e Fluidez
- Frases curtas dominam (3-10 palavras)
- Frases médias para desenvolver (12-18 palavras)
- Nunca frases longas (20+ palavras)
- Parágrafos de 1-2 linhas máximo

### Pontuação Emocional
- "E então!?" para criar ritmo e tensão
- Reticências para suspense antes de revelação
- Ponto final seco para afirmações fortes

### Formatação
- **Negrito** apenas para conceitos-chave (máximo 3 por texto)
- Bullet points só para listas de tarefas
- Sem emojis no corpo
- Espaçamento generoso entre blocos

### Tom de Voz
- Empático, nunca condescendente
- Direto, nunca agressivo
- Confiante, nunca arrogante
- Cru, nunca vulgar

### Proibido
- "Eu ajudo [perfil] a [resultado]"
- "Especialista em..."
- "Apaixonado por..."
- "Há X anos no mercado"
- Listas de credenciais
- Emojis como bullet points
- Promessas vagas sem prazo

---

## Checklist Final

Antes de entregar, verifique:

### Estrutura
- [ ] Abre validando competência do leitor?
- [ ] Cria contraste entre competência e percepção?
- [ ] Mostra consequência tangível?
- [ ] Descreve frustração em linguagem crua?
- [ ] Nomeia o sentimento resultante?
- [ ] Usa metáfora visual para a solução?
- [ ] Tem prova de ação recente?
- [ ] CTA é uma única ação?
- [ ] Garantia assume o risco?

### Identificação
- [ ] Lista profissões específicas?
- [ ] Menciona tarefas do dia a dia?
- [ ] Leitor pensa "isso sou eu" nos primeiros parágrafos?

### Emoção
- [ ] Dor descrita de forma vívida?
- [ ] Comparação injusta presente?
- [ ] Sentimento profundo nomeado?

### Escrita
- [ ] Frases majoritariamente curtas?
- [ ] Zero jargões e clichês?
- [ ] Lê como conversa, não como copy?
- [ ] "E então!?" usado para ritmo?

---

## Exemplos por Nicho

### Nutricionista

Provavelmente, você é um Nutricionista incrível.
Formado, atualizado, com protocolos que funcionam…
…que poderia estar entre os melhores na sua área.

Mas no Instagram, não consegue mostrar seu diferencial nem atrair pacientes que pagam bem.

E então!?
Sua agenda fica vazia enquanto colegas lotam com dietas de PDF.
E então!?
Você cobra R$150 enquanto nutri de 2 anos de formada cobra R$400.

Com certeza, você já passou por isso.

Tem um protocolo validado e precisa:
• Explicar seu método;
• Escrever legendas que vendem;
• Mostrar resultados de pacientes.

Mas, ao digitar…
Parece texto de nutricionista genérico.

Outro profissional escreve a mesma coisa…
E parece referência na área.

Então…
Você se sente invisível.

O conteúdo nesse perfil será como um filtro:
vai separar quem busca emagrecimento rápido de quem quer saúde de verdade.

Você saberá como comunicar valor, atrair pacientes certos e cobrar o que merece.

Seu Instagram não será mais ignorado.
Será autoridade e fonte de pacientes.

Você vai se posicionar como a nutricionista que entende do assunto — a escolha óbvia pra quem leva saúde a sério.

Eu acabei de reestruturar minha comunicação do zero, pra te mostrar na prática.

Se você está lendo isso… segue.

Se, no máximo em 7 dias,
eu não mudar sua forma de atrair pacientes qualificados…
Dê unfollow. Eu terei falhado.

---

### Advogado

Provavelmente, você é um Advogado incrível.
Um tributarista, trabalhista, civilista…
talvez seja um criminalista, previdenciarista, empresarial…
…que poderia estar entre os melhores da sua especialidade.

Mas no digital, não consegue se diferenciar nem atrair clientes que pagam honorários justos.

E então!?
Poucos enxergam sua competência técnica.
E então!?
Você perde causas pra advogados que só sabem fazer marketing.

Com certeza, você já passou por isso.

Tem conhecimento profundo e precisa:
• Explicar áreas de atuação;
• Escrever posts que atraem clientes;
• Mostrar autoridade sem parecer desesperado.

Mas, ao postar…
Parece mais um advogado falando juridiquês.

Outro profissional fala a mesma coisa…
E soa como autoridade máxima.

Então…
Você se sente subestimado.

O conteúdo nesse perfil será como uma petição bem fundamentada:
vai convencer antes de precisar argumentar.

Você saberá como traduzir expertise, atrair casos relevantes e cobrar honorários dignos.

Seu Instagram não será mais cartão de visita esquecido.
Será fonte de clientes qualificados.

Você vai se posicionar como o advogado que resolve — a primeira opção quando o problema é sério.

Eu acabei de reconstruir meu posicionamento do zero, pra te mostrar que funciona.

Se você está lendo isso… segue.

Se, no máximo em 14 dias,
eu não mudar sua forma de atrair clientes…
Dê unfollow. Eu terei falhado.

---

### Terapeuta

Provavelmente, você é uma Terapeuta incrível.
Uma psicóloga, consteladora, terapeuta holística…
talvez seja uma coach, hipnoterapeuta, analista…
…que poderia estar entre as melhores na sua abordagem.

Mas no Instagram, não consegue transmitir sua essência nem atrair clientes que valorizam o processo.

E então!?
Poucos entendem a profundidade do seu trabalho.
E então!?
Você atende por R$100 enquanto terapeutas com menos preparo cobram R$350.

Com certeza, você já passou por isso.

Tem uma abordagem transformadora e precisa:
• Comunicar seu diferencial;
• Escrever conteúdos que conectam;
• Atrair pacientes comprometidos.

Mas, ao escrever…
Parece autoajuda genérica.

Outra terapeuta posta a mesma reflexão…
E parece profunda e conectada.

Então…
Você se sente uma fraude.

O conteúdo nesse perfil será como um espelho:
vai refletir exatamente o que seu cliente ideal precisa ver.

Você saberá como comunicar com alma, atrair quem está pronto e cobrar pelo valor real do seu trabalho.

Seu Instagram não será mais vitrine vazia.
Será extensão do seu consultório.

Você vai se posicionar como a terapeuta que transforma — a escolha certa pra quem quer mudança real.

Eu acabei de reconstruir minha presença do zero, pra te mostrar o caminho.

Se você está lendo isso… segue.

Se, no máximo em 7 dias,
eu não mudar sua forma de atrair pacientes certos…
Dê unfollow. Eu terei falhado.

---

## Protocolo de Entrega

1. **Formato:** Entregar texto completo com blocos separados por linha
2. **Extras:** Após o texto, sugerir:
   - 3 variações de metáfora para o Bloco 9
   - 2 variações de garantia para o Bloco 15
   - Versão resumida para bio do Instagram (150 caracteres)

---

## Ativação

"Me conta: qual seu nicho e quem é seu cliente ideal?"

Executo todo o framework e entrego pronto.
